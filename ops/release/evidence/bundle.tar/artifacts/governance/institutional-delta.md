# Institutional Delta

Deterministic release delta generated from governed compatibility artifacts.

## Breaking changes

- None.

## Active deprecations

- `DEP-CHART-AUTOSCALING`: `autoscaling` -> `hpa` (removal target `2026-09-01`)
- `DEP-CHART-CONTAINER-SECURITY-CONTEXT`: `securityContext` -> `containerSecurityContext` (removal target `2026-09-01`)
- `DEP-CHART-SERVICE-MONITOR`: `serviceMonitor` -> `metrics.serviceMonitor` (removal target `2026-09-01`)
- `DEP-CHART-NETWORKPOLICY-INGRESS-MODE`: `networkPolicy.ingressMode` -> `networkPolicy.ingress.mode` (removal target `2026-09-01`)
- `DEP-CHART-NETWORKPOLICY-MONITORING-NAMESPACE`: `networkPolicy.allowMonitoringNamespace` -> `networkPolicy.monitoring.allowNamespace` (removal target `2026-09-01`)
- `DEP-DOCS-ROOT-COMPATIBILITY-POLICY`: `docs/root/compatibility-policy.md` -> `docs/08-contracts/ownership-and-versioning.md` (removal target `2027-03-03`)
- `DEP-DOCS-CONTRACTS-COMPATIBILITY`: `docs/contracts/compatibility.md` -> `docs/08-contracts/ownership-and-versioning.md` (removal target `2027-03-03`)
